const CACHE_NAME = "ta-by-aoi-v1";

const FILES = [
  "login.html",
  "teacher.html",
  "student.html",
  "style.css",
  "script.js",
  "manifest.json",
  "icon.png"
];

self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(FILES))
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request))
  );
});