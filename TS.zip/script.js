const subject = localStorage.getItem("subject");
document.getElementById("sub").innerText = subject;

let qs = JSON.parse(localStorage.getItem("questions"))||{};
let questions = qs[subject]||[];
let time = localStorage.getItem("examDuration")||300;
let timer;

function shuffle(a){
  for(let i=a.length-1;i>0;i--){
    let j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
}

shuffle(questions);

function startTest(){
  if(!questions.length){alert("No questions");return;}
  startBox.style.display="none";
  quizBox.style.display="block";
  load();
  timer=setInterval(()=>{
    time--;
    timerEl.innerText=`Time left: ${Math.floor(time/60)}:${time%60}`;
    if(time<=0) submitTest();
  },1000);
}

function load(){
  quiz.innerHTML="";
  questions.forEach((q,i)=>{
    shuffle(Object.values(q.options));
    quiz.innerHTML+=`<p>${i+1}. ${q.question}</p>`+
      Object.entries(q.options).map(o=>
        `<label><input type="radio" name="q${i}" value="${o[0]}" onclick="update()"> ${o[1]}</label><br>`
      ).join("");
  });
}

function update(){
  let done=0;
  questions.forEach((_,i)=>{
    if(document.querySelector(`input[name=q${i}]:checked`)) done++;
  });
  let p=Math.floor(done/questions.length*100);
  progress.value=p; percent.innerText=p+"%";
}

function submitTest(){
  clearInterval(timer);
  let score=0;
  questions.forEach((q,i)=>{
    let a=document.querySelector(`input[name=q${i}]:checked`);
    if(a && a.value===q.answer) score++;
  });
  result.innerText=`Score: ${score}/${questions.length}`;

  let scores=JSON.parse(localStorage.getItem("scores"))||[];
  scores.push({
    name:localStorage.getItem("name"),
    regno:localStorage.getItem("regno"),
    subject,
    score,
    school:localStorage.getItem("school")
  });
  localStorage.setItem("scores",JSON.stringify(scores));
}